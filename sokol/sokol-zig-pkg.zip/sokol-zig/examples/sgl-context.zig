//------------------------------------------------------------------------------
//  sgl-context.zig
//
//  Demonstrates how to render into different render passes with sokol-gl.
//  using contexts.
//------------------------------------------------------------------------------
const sokol = @import("sokol");
const slog = sokol.log;
const sg = sokol.gfx;
const sapp = sokol.app;
const sglue = sokol.glue;
const sgl = sokol.gl;
const math = @import("std").math;

const state = struct {
    const offscreen = struct {
        var pass: sg.Pass = .{};
        var sgl_ctx: sgl.Context = .{};
    };
    const display = struct {
        var pass_action: sg.PassAction = .{};
        var tex_view: sg.View = .{};
        var smp: sg.Sampler = .{};
        var sgl_pip: sgl.Pipeline = .{};
    };
};

const offscreen_pixel_format = sg.PixelFormat.RGBA8;
const offscreen_sample_count = 1;
const offscreen_width = 32;
const offscreen_height = 32;

export fn init() void {
    // setup sokol-gfx
    sg.setup(.{
        .environment = sglue.environment(),
        .logger = .{ .func = slog.func },
    });

    // setup sokol-gl with the default context compatible with the default
    // render pass (which means just keep pixelformats and sample count at defaults)
    //
    // reduce the vertex- and command-count though, otherwise we just waste memory
    //
    sgl.setup(.{
        .max_vertices = 64,
        .max_commands = 16,
        .logger = .{ .func = slog.func },
    });

    // initialize a pass action struct for the default pass to clear to a light-blue color
    state.display.pass_action.colors[0] = .{
        .load_action = .CLEAR,
        .clear_value = .{ .r = 0.5, .g = 0.7, .b = 1, .a = 1 },
    };

    // create a sokol-gl pipeline object for 3D rendering into the default pass
    state.display.sgl_pip = sgl.contextMakePipeline(sgl.defaultContext(), .{
        .cull_mode = .BACK,
        .depth = .{
            .write_enabled = true,
            .compare = .LESS_EQUAL,
        },
    });

    // create a sokol-gl context compatible with the offscreen render pass
    // (specific color pixel format, no depth-stencil-surface, no MSAA)
    state.offscreen.sgl_ctx = sgl.makeContext(.{
        .max_vertices = 8,
        .max_commands = 4,
        .color_format = offscreen_pixel_format,
        .depth_format = .NONE,
        .sample_count = offscreen_sample_count,
    });

    // create an color attachment image for the offscreen pass and associated views
    const img = sg.makeImage(.{
        .usage = .{ .color_attachment = true },
        .width = offscreen_width,
        .height = offscreen_height,
        .pixel_format = offscreen_pixel_format,
        .sample_count = offscreen_sample_count,
    });
    state.offscreen.pass.attachments.colors[0] = sg.makeView(.{
        .color_attachment = .{ .image = img },
    });
    state.display.tex_view = sg.makeView(.{
        .texture = .{ .image = img },
    });

    // the offscreen render pass clear color
    state.offscreen.pass.action.colors[0] = .{
        .load_action = .CLEAR,
        .clear_value = .{ .r = 0, .g = 0, .b = 0, .a = 1 },
    };

    // sampler for sampling the offscreen render target
    state.display.smp = sg.makeSampler(.{
        .wrap_u = .CLAMP_TO_EDGE,
        .wrap_v = .CLAMP_TO_EDGE,
        .min_filter = .NEAREST,
        .mag_filter = .NEAREST,
    });
}

export fn frame() void {
    const a = sgl.asRadians(@floatFromInt(sapp.frameCount()));

    // draw a rotating quad into the offscreen render target texture
    sgl.setContext(state.offscreen.sgl_ctx);
    sgl.defaults();
    sgl.matrixModeModelview();
    sgl.rotate(a, 0, 0, 1);
    drawQuad();

    // draw a rotating 3D cube, using the offscreen render target as texture
    sgl.setContext(sgl.defaultContext());
    sgl.defaults();
    sgl.enableTexture();
    sgl.texture(state.display.tex_view, state.display.smp);
    sgl.loadPipeline(state.display.sgl_pip);
    sgl.matrixModeProjection();
    sgl.perspective(sgl.asRadians(45.0), sapp.widthf() / sapp.heightf(), 0.1, 100.0);
    const eye = .{
        math.sin(a) * 6.0,
        math.sin(a) * 3.0,
        math.cos(a) * 6.0,
    };
    sgl.matrixModeModelview();
    sgl.lookat(eye[0], eye[1], eye[2], 0, 0, 0, 0, 1, 0);
    drawCube();

    // do the actual offscreen and display rendering in sokol-gfx passes
    sg.beginPass(state.offscreen.pass);
    sgl.contextDraw(state.offscreen.sgl_ctx);
    sg.endPass();
    sg.beginPass(.{ .action = state.display.pass_action, .swapchain = sglue.swapchain() });
    sgl.contextDraw(sgl.defaultContext());
    sg.endPass();
    sg.commit();
}

export fn cleanup() void {
    sgl.shutdown();
    sg.shutdown();
}

pub fn main() void {
    sapp.run(.{
        .init_cb = init,
        .frame_cb = frame,
        .cleanup_cb = cleanup,
        .width = 800,
        .height = 600,
        .sample_count = 4,
        .icon = .{ .sokol_default = true },
        .window_title = "sgl-context.zig",
        .logger = .{ .func = slog.func },
    });
}

fn drawQuad() void {
    sgl.beginQuads();
    sgl.v2fC3b(0.0, -1.0, 255, 0, 0);
    sgl.v2fC3b(1.0, 0.0, 0, 0, 255);
    sgl.v2fC3b(0.0, 1.0, 0, 255, 255);
    sgl.v2fC3b(-1.0, 0.0, 0, 255, 0);
    sgl.end();
}

fn drawCube() void {
    sgl.beginQuads();
    sgl.v3fT2f(-1.0, 1.0, -1.0, 0.0, 1.0);
    sgl.v3fT2f(1.0, 1.0, -1.0, 1.0, 1.0);
    sgl.v3fT2f(1.0, -1.0, -1.0, 1.0, 0.0);
    sgl.v3fT2f(-1.0, -1.0, -1.0, 0.0, 0.0);
    sgl.v3fT2f(-1.0, -1.0, 1.0, 0.0, 1.0);
    sgl.v3fT2f(1.0, -1.0, 1.0, 1.0, 1.0);
    sgl.v3fT2f(1.0, 1.0, 1.0, 1.0, 0.0);
    sgl.v3fT2f(-1.0, 1.0, 1.0, 0.0, 0.0);
    sgl.v3fT2f(-1.0, -1.0, 1.0, 0.0, 1.0);
    sgl.v3fT2f(-1.0, 1.0, 1.0, 1.0, 1.0);
    sgl.v3fT2f(-1.0, 1.0, -1.0, 1.0, 0.0);
    sgl.v3fT2f(-1.0, -1.0, -1.0, 0.0, 0.0);
    sgl.v3fT2f(1.0, -1.0, 1.0, 0.0, 1.0);
    sgl.v3fT2f(1.0, -1.0, -1.0, 1.0, 1.0);
    sgl.v3fT2f(1.0, 1.0, -1.0, 1.0, 0.0);
    sgl.v3fT2f(1.0, 1.0, 1.0, 0.0, 0.0);
    sgl.v3fT2f(1.0, -1.0, -1.0, 0.0, 1.0);
    sgl.v3fT2f(1.0, -1.0, 1.0, 1.0, 1.0);
    sgl.v3fT2f(-1.0, -1.0, 1.0, 1.0, 0.0);
    sgl.v3fT2f(-1.0, -1.0, -1.0, 0.0, 0.0);
    sgl.v3fT2f(-1.0, 1.0, -1.0, 0.0, 1.0);
    sgl.v3fT2f(-1.0, 1.0, 1.0, 1.0, 1.0);
    sgl.v3fT2f(1.0, 1.0, 1.0, 1.0, 0.0);
    sgl.v3fT2f(1.0, 1.0, -1.0, 0.0, 0.0);
    sgl.end();
}
