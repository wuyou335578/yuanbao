const std = @import("std");
pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    const mod = b.createModule(.{
        .root_source_file = b.path("src/sokol/sokol.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });

    const csrcs = [_][]const u8{
        "sokol_log.c", "sokol_gfx.c", "sokol_app.c", "sokol_time.c",
        "sokol_audio.c", "sokol_gl.c", "sokol_glue.c", "sokol_shape.c",
        "sokol_debugtext.c", "sokol_fetch.c", "sokol_cmdbuf.c",
    };
    inline for (csrcs) |c| {
        mod.addCSourceFile(.{ .file = b.path("src/sokol/c/" ++ c), .flags = &.{"-DIMPL", "-DSOKOL_GLCORE"} });
    }

    const lib = b.addLibrary(.{
        .name = "sokol",
        .root_module = mod,
        .linkage = .static,
    });
    b.installArtifact(lib);
}
