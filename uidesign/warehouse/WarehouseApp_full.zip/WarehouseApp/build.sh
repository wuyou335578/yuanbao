#!/bin/bash
# 仓储管理 APK 构建脚本（适配元宝沙盒：aapt + javac + dx + zipalign + apksigner）
set -e
AJ=/data/workspace/android_pkg/android-23.jar
DX=/data/workspace/android_pkg/dx.jar
cd "$(dirname "$0")"
rm -rf gen obj out; mkdir -p gen obj out

echo "[1/6] aapt 生成 R.java"
aapt package -m -J gen/ -M AndroidManifest.xml -S res/ -I "$AJ"

echo "[2/6] javac 编译"
SRCS=$(find src gen -name "*.java")
javac -nowarn -encoding UTF-8 -source 8 -target 8 -bootclasspath "$AJ" -d obj/ $SRCS 2>&1 | grep -v "warning" || true

echo "[3/6] dx 转 dex"
java -jar "$DX" --dex --output=out/classes.dex obj/ 2>&1 | tail -2

echo "[4/6] 打包 + 注入 dex"
aapt package -f -M AndroidManifest.xml -S res/ -I "$AJ" -F out/unsigned.apk
(cd out && aapt add unsigned.apk classes.dex >/dev/null)

echo "[5/6] zipalign"
zipalign -f 4 out/unsigned.apk out/aligned.apk

echo "[6/6] 签名"
if [ ! -f out/app.ks ]; then
  keytool -genkeypair -keystore out/app.ks -alias yuanbao -keyalg RSA \
    -keysize 2048 -validity 10000 -storepass 123456 -keypass 123456 \
    -dname "CN=Yuanbao, O=Tencent, C=CN" >/dev/null 2>&1
fi
apksigner sign --ks out/app.ks --ks-pass pass:123456 \
  --key-pass pass:123456 --out Warehouse.apk out/aligned.apk

echo ""
echo "=== 构建完成 ==="
apksigner verify Warehouse.apk >/dev/null 2>&1 && echo "验签: 通过" || echo "验签: 失败"
aapt dump badging Warehouse.apk 2>/dev/null | head -3
echo "--- dex 内业务类 ---"
unzip -p Warehouse.apk classes.dex > /tmp/w.dex 2>/dev/null && strings /tmp/w.dex | grep -c "com/example/warehouse" || true
