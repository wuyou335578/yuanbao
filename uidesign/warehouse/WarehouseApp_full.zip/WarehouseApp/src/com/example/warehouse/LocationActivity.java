package com.example.warehouse;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

/** 库位查询：按库位编码反查该库位上的 SKU */
public class LocationActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Activity self = this;

        android.widget.LinearLayout root = Ui.root(this);
        root.addView(Ui.muted(this, "接口：" + ApiContract.PATH_LOCATION));

        final EditText et = Ui.field(this, "库位编码，如 A-01", false);
        root.addView(et);

        Button btn = Ui.button(this, "查询库位");
        root.addView(btn);

        final ListView list = new ListView(this);
        list.setLayoutParams(Ui.lp());
        root.addView(list);

        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ApiContract.Sku[] r = ApiContract.search(et.getText().toString());
                String[] lines = new String[r.length];
                for (int i = 0; i < r.length; i++) lines[i] = r[i].line();
                list.setAdapter(new ArrayAdapter<String>(self,
                        android.R.layout.simple_list_item_1, lines));
            }
        });
        setContentView(root);
    }
}
