package com.example.warehouse;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/** 登录页：本地校验（MOCK）或按 ApiContract 走 /auth/login */
public class LoginActivity extends Activity {

    private EditText etUser, etPwd;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Activity self = this;

        android.widget.LinearLayout root = Ui.root(this);
        root.addView(Ui.muted(this, "服务地址：" + Session.baseUrl));
        etUser = Ui.field(this, "账号", false);
        etPwd  = Ui.field(this, "密码", true);
        root.addView(etUser);
        root.addView(etPwd);

        Button btn = Ui.button(this, "登  录");
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String u = etUser.getText().toString().trim();
                String p = etPwd.getText().toString();
                if (u.length() == 0 || p.length() == 0) {
                    Toast.makeText(self, "请输入账号和密码", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (ApiContract.USE_MOCK) {
                    if (!ApiContract.mockLogin(u, p)) {
                        Toast.makeText(self, "账号或密码错误", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Session.token = "mock-token-" + System.currentTimeMillis();
                } else {
                    // 真实模式下由 ApiClient 完成，此处占位：
                    // POST BASE_URL + ApiContract.AUTH_LOGIN
                    Session.token = "";
                }
                Session.username = u;
                startActivity(new Intent(self, MainActivity.class));
                finish();
            }
        });
        root.addView(btn);
        root.addView(Ui.muted(this, "演示模式：任意非空账号密码均可登录"));
        setContentView(root);
    }
}
