package com.example.warehouse;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/** 我的：账号信息、服务器配置说明、接口契约一览、退出登录 */
public class ProfileActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Activity self = this;

        android.widget.LinearLayout root = Ui.root(this);
        root.addView(Ui.info(this, "账号：" + Session.username));
        root.addView(Ui.info(this, "终端号：" + Session.terminal));
        root.addView(Ui.info(this, "版本：1.0 (build 1)"));
        root.addView(Ui.divider(this));

        root.addView(Ui.section(this, "服务配置"));
        root.addView(Ui.muted(this, "BASE_URL：" + Session.baseUrl));
        root.addView(Ui.muted(this, "鉴权：Bearer Token，有效期 " + ApiContract.TOKEN_TTL + " 秒"));
        root.addView(Ui.muted(this, "MOCK 模式：" + (ApiContract.USE_MOCK ? "开（不联网）" : "关（真实请求）")));

        root.addView(Ui.section(this, "接口契约"));
        String[][] eps = ApiContract.ENDPOINTS;
        for (int i = 0; i < eps.length; i++) {
            root.addView(Ui.muted(this, eps[i][0] + " " + eps[i][1]));
        }

        Button out = Ui.button(this, "退出登录");
        out.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Session.clear();
                startActivity(new Intent(self, LoginActivity.class));
                finish();
            }
        });
        root.addView(out);
        setContentView(root);
    }
}
