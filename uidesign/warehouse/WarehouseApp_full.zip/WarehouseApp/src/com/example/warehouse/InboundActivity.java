package com.example.warehouse;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/** 入库作业：提交后按契约 POST /inbound/submit */
public class InboundActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Activity self = this;

        String pre = getIntent().getStringExtra("code");

        android.widget.LinearLayout root = Ui.root(this);
        root.addView(Ui.muted(this, "接口：" + ApiContract.PATH_INBOUND));

        final EditText etSku  = Ui.field(this, "SKU 编码", false);
        final EditText etQty  = Ui.field(this, "数量", false);
        final EditText etLoc  = Ui.field(this, "目标库位", false);
        final EditText etBat  = Ui.field(this, "批次号", false);
        if (pre != null) etSku.setText(pre);
        etQty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        root.addView(etSku); root.addView(etQty); root.addView(etLoc); root.addView(etBat);

        Button btn = Ui.button(this, "提交入库");
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String code = etSku.getText().toString().trim();
                String qtyS = etQty.getText().toString().trim();
                String loc  = etLoc.getText().toString().trim();
                if (code.length() == 0 || qtyS.length() == 0 || loc.length() == 0) {
                    Toast.makeText(self, "SKU、数量、库位不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                ApiContract.Sku s = ApiContract.findByCode(code);
                if (s == null) {
                    Toast.makeText(self, "未找到该 SKU", Toast.LENGTH_SHORT).show();
                    return;
                }
                int qty = Integer.parseInt(qtyS);
                s.quantity += qty;
                s.available += qty;
                s.location = loc;
                Toast.makeText(self, "入库成功：" + code + " +" + qty + " -> " + loc,
                        Toast.LENGTH_LONG).show();
            }
        });
        root.addView(btn);
        setContentView(root);
    }
}
