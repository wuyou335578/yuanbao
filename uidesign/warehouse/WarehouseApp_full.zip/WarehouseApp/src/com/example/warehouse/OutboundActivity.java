package com.example.warehouse;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/** 出库作业：校验可用库存后按契约 POST /outbound/submit */
public class OutboundActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Activity self = this;

        String pre = getIntent().getStringExtra("code");

        android.widget.LinearLayout root = Ui.root(this);
        root.addView(Ui.muted(this, "接口：" + ApiContract.PATH_OUTBOUND));

        final EditText etSku = Ui.field(this, "SKU 编码", false);
        final EditText etQty = Ui.field(this, "数量", false);
        final EditText etLoc = Ui.field(this, "出库库位", false);
        final EditText etOrd = Ui.field(this, "订单号", false);
        if (pre != null) etSku.setText(pre);
        etQty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        root.addView(etSku); root.addView(etQty); root.addView(etLoc); root.addView(etOrd);

        Button btn = Ui.button(this, "提交出库");
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String code = etSku.getText().toString().trim();
                String qtyS = etQty.getText().toString().trim();
                if (code.length() == 0 || qtyS.length() == 0) {
                    Toast.makeText(self, "SKU 与数量不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                ApiContract.Sku s = ApiContract.findByCode(code);
                if (s == null) {
                    Toast.makeText(self, "未找到该 SKU", Toast.LENGTH_SHORT).show();
                    return;
                }
                int qty = Integer.parseInt(qtyS);
                if (qty > s.available) {
                    Toast.makeText(self, "可用库存不足，当前可用 " + s.available,
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                s.quantity -= qty;
                s.available -= qty;
                Toast.makeText(self, "出库成功：" + code + " -" + qty, Toast.LENGTH_LONG).show();
            }
        });
        root.addView(btn);
        setContentView(root);
    }
}
