package com.example.warehouse;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

/** 库存盘点：录入实盘数量，计算差异后按契约 POST /stocktake/submit */
public class StocktakeActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Activity self = this;

        android.widget.LinearLayout root = Ui.root(this);
        root.addView(Ui.muted(this, "接口：" + ApiContract.PATH_STOCKTAKE));

        final EditText etSku = Ui.field(this, "SKU 编码", false);
        final EditText etReal = Ui.field(this, "实盘数量", false);
        etReal.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        root.addView(etSku);
        root.addView(etReal);

        Button btn = Ui.button(this, "提交盘点");
        root.addView(btn);

        root.addView(Ui.section(this, "账面库存"));
        ListView list = new ListView(this);
        list.setLayoutParams(Ui.lp());
        root.addView(list);

        ApiContract.Sku[] all = ApiContract.DEMO_SKUS;
        String[] lines = new String[all.length];
        for (int i = 0; i < all.length; i++) {
            lines[i] = all[i].code + "  " + all[i].name + "  账面 " + all[i].quantity + all[i].unit;
        }
        list.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, lines));

        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String code = etSku.getText().toString().trim();
                String rS = etReal.getText().toString().trim();
                if (code.length() == 0 || rS.length() == 0) {
                    Toast.makeText(self, "请填写编码与实盘数量", Toast.LENGTH_SHORT).show();
                    return;
                }
                ApiContract.Sku s = ApiContract.findByCode(code);
                if (s == null) {
                    Toast.makeText(self, "未找到该 SKU", Toast.LENGTH_SHORT).show();
                    return;
                }
                int real = Integer.parseInt(rS);
                int diff = real - s.quantity;
                s.quantity = real;
                s.available = real;
                Toast.makeText(self, "盘点已提交，差异 " + (diff >= 0 ? "+" : "") + diff,
                        Toast.LENGTH_LONG).show();
            }
        });

        setContentView(root);
    }
}
