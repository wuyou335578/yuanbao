package com.example.warehouse;

/** 登录态与本地配置（等价于 Android 端的轻量会话存储） */
public final class Session {
    public static String token = "";
    public static String username = "";
    public static String terminal = "PDA-" + (System.currentTimeMillis() % 100000);
    public static String baseUrl = ApiContract.BASE_URL;

    public static boolean loggedIn() { return token != null && token.length() > 0; }

    public static void clear() { token = ""; username = ""; }

    private Session() {}
}
