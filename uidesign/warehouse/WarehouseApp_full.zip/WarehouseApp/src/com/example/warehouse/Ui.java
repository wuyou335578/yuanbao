package com.example.warehouse;

import android.content.Context;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 轻量 UI 构造工具：统一间距、字号、配色，避免每个页面重复造轮子 */
public final class Ui {

    public static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    /** 页面根容器 */
    public static LinearLayout root(Context c) {
        LinearLayout ll = new LinearLayout(c);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setBackgroundColor(0xFFF5F6F8);
        ll.setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16));
        ll.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return ll;
    }

    public static LinearLayout.LayoutParams lp() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    /** 输入行：标签 + 输入框 */
    public static EditText field(Context c, String label, boolean password) {
        TextView tv = new TextView(c);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setTextColor(0xFF888888);
        tv.setLayoutParams(lp());
        // 由调用方决定插入位置，这里只返回输入框，标签通过 tag 返回不方便，
        // 因此改为直接返回输入框，标签用 hint 呈现，保证调用简洁
        EditText et = new EditText(c);
        et.setHint(label);
        et.setSingleLine(true);
        et.setTextSize(16);
        et.setTextColor(0xFF191919);
        et.setBackgroundColor(0xFFFFFFFF);
        et.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12));
        if (password) et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams p = lp();
        p.topMargin = dp(c, 8);
        et.setLayoutParams(p);
        return et;
    }

    /** 主按钮 */
    public static Button button(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextSize(16);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundColor(0xFF2F6FED);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = lp();
        p.topMargin = dp(c, 16);
        b.setLayoutParams(p);
        return b;
    }

    /** 次按钮（描边） */
    public static Button ghost(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextSize(15);
        b.setTextColor(0xFF2F6FED);
        b.setBackgroundColor(0xFFFFFFFF);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = lp();
        p.topMargin = dp(c, 10);
        b.setLayoutParams(p);
        return b;
    }

    /** 信息行 */
    public static TextView info(Context c, String text) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTextColor(0xFF191919);
        tv.setPadding(0, dp(c, 6), 0, dp(c, 6));
        tv.setLayoutParams(lp());
        return tv;
    }

    public static TextView muted(Context c, String text) {
        TextView tv = info(c, text);
        tv.setTextSize(13);
        tv.setTextColor(0xFF888888);
        return tv;
    }

    /** 标题（页面内小标题） */
    public static TextView section(Context c, String text) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setTextColor(0xFF888888);
        LinearLayout.LayoutParams p = lp();
        p.topMargin = dp(c, 18);
        tv.setLayoutParams(p);
        return tv;
    }

    /** 分割线 */
    public static TextView divider(Context c) {
        TextView tv = new TextView(c);
        tv.setHeight(1);
        tv.setBackgroundColor(0xFFE5E5E5);
        LinearLayout.LayoutParams p = lp();
        p.topMargin = dp(c, 12);
        p.bottomMargin = dp(c, 12);
        tv.setLayoutParams(p);
        return tv;
    }

    /** 宫格一行：两个等宽按钮 */
    public static LinearLayout gridRow(Context c, Button a, Button b) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams p = lp();
        p.topMargin = dp(c, 10);
        row.setLayoutParams(p);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(c, 56), 1f);
        half.rightMargin = dp(c, 8);
        a.setLayoutParams(half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(c, 56), 1f);
        half2.leftMargin = dp(c, 8);
        b.setLayoutParams(half2);
        row.addView(a);
        row.addView(b);
        return row;
    }

    private Ui() {}
}
