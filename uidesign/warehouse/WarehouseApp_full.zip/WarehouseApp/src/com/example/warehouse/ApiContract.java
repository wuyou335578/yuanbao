package com.example.warehouse;

/**
 * ============================================================
 *  后端接口契约（包内声明 / API Contract）
 *  这是本 App 与服务端之间约定的唯一权威来源。
 *  任何页面需要调接口，一律引用本文件的常量，禁止硬编码 URL。
 * ============================================================
 *
 *  【1】服务地址
 *      BASE_URL 为占位地址，部署时通过「我的 -> 服务器配置」覆盖，
 *      覆盖值存于本地 SharedPreferences，键名见 KEY_BASE_URL。
 *
 *  【2】鉴权方式
 *      Bearer Token。
 *      - 登录成功返回 access_token，有效期 TOKEN_TTL 秒；
 *      - 每次请求携带请求头：Authorization: Bearer <access_token>
 *      - 令牌过期返回 HTTP 401 且 body.code = TOKEN_EXPIRED，
 *        客户端用 refresh_token 调 /auth/refresh 换新 token 后重试一次。
 *      - 请求头另带：Content-Type: application/json; charset=utf-8
 *                    X-Client: android
 *                    X-Terminal: 手持终端编号（设备标识）
 *
 *  【3】统一响应结构（所有接口）
 *      { "code": 0, "message": "ok", "data": { ... } }
 *      code = 0 表示业务成功，非 0 为失败，message 为可直接展示的中文提示。
 *      业务码：0 成功 / 401 未登录或令牌过期 / 403 无权限 / 404 对象不存在
 *              422 参数校验失败 / 500 服务端异常
 *
 *  【4】接口清单（见 ENDPOINTS 与 PATH_ 常量）
 *
 *  【5】运行模式
 *      USE_MOCK = true 时全部走本地假数据，不发起任何网络请求（离线演示）；
 *      置为 false 则走 HttpURLConnection 真实请求。
 */
public final class ApiContract {

    // ---------- 1. 服务地址 ----------
    public static final String BASE_URL = "https://wms.example.com/api/v1";
    public static final String KEY_BASE_URL = "pref_base_url";

    // ---------- 2. 鉴权 ----------
    public static final String AUTH_LOGIN   = "/auth/login";
    public static final String AUTH_REFRESH = "/auth/refresh";
    public static final String AUTH_LOGOUT  = "/auth/logout";
    public static final long   TOKEN_TTL    = 7200L;          // 秒
    public static final int    CODE_TOKEN_EXPIRED = 401;

    public static final String HEADER_AUTH      = "Authorization";
    public static final String HEADER_CLIENT    = "X-Client";
    public static final String HEADER_TERMINAL  = "X-Terminal";

    // ---------- 3. 接口清单 ----------
    public static final String PATH_SKU_LIST   = "/sku/list";        // GET  关键词分页查询
    public static final String PATH_SKU_DETAIL = "/sku/detail";      // GET  按编码查详情
    public static final String PATH_LOCATION   = "/location/query";  // GET  库位查询
    public static final String PATH_STOCK      = "/stock/query";     // GET  库存查询
    public static final String PATH_INBOUND    = "/inbound/submit";  // POST 入库提交
    public static final String PATH_OUTBOUND   = "/outbound/submit"; // POST 出库提交
    public static final String PATH_STOCKTAKE  = "/stocktake/submit";// POST 盘点提交

    /** 全部接口一览，供「我的 -> 接口契约」页面展示 */
    public static final String[][] ENDPOINTS = {
        {"POST", AUTH_LOGIN,   "登录，入参 {username,password}，出参 {access_token,refresh_token,expires_in}"},
        {"POST", AUTH_REFRESH, "刷新令牌，入参 {refresh_token}，出参 {access_token,expires_in}"},
        {"POST", AUTH_LOGOUT,  "退出登录，使当前令牌失效"},
        {"GET",  PATH_SKU_LIST,   "SKU 分页查询，入参 ?keyword=&page=&size=，出参 {total,list[]}"},
        {"GET",  PATH_SKU_DETAIL, "SKU 详情，入参 ?code=，出参 {sku 对象}"},
        {"GET",  PATH_LOCATION,   "库位查询，入参 ?code=，出参 {location,skuList[]}"},
        {"GET",  PATH_STOCK,      "库存查询，入参 ?skuCode=&location=，出参 {quantity,available}"},
        {"POST", PATH_INBOUND,    "入库提交，入参 {skuCode,quantity,location,batchNo,operator}"},
        {"POST", PATH_OUTBOUND,   "出库提交，入参 {skuCode,quantity,location,orderNo,operator}"},
        {"POST", PATH_STOCKTAKE,  "盘点提交，入参 {list:[{skuCode,location,bookQty,realQty}]}"}
    };

    // ---------- 5. 运行模式 ----------
    public static final boolean USE_MOCK = true;   // true=本地假数据，false=真实请求

    // ---------- 数据模型 ----------
    public static class Sku {
        public String code;      // SKU 编码
        public String name;      // 品名
        public String spec;      // 规格
        public String location;  // 库位
        public int    quantity;  // 库存数量
        public int    available; // 可用数量
        public String batchNo;   // 批次号
        public String unit;      // 单位

        public Sku(String c, String n, String s, String l, int q, int a, String b, String u) {
            code = c; name = n; spec = s; location = l;
            quantity = q; available = a; batchNo = b; unit = u;
        }
        public String line() {
            return code + "  " + name + "\n" + location + "  库存 " + quantity + unit;
        }
    }

    /** 本地演示数据（USE_MOCK 时作为数据源） */
    public static final Sku[] DEMO_SKUS = new Sku[] {
        new Sku("SKU-100231", "内六角螺栓 M8", "M8x40 不锈钢", "A-01-03-2", 1280, 1280, "B20240901", "个"),
        new Sku("SKU-100232", "内六角螺栓 M10", "M10x50 不锈钢", "A-01-03-3", 860, 860, "B20240901", "个"),
        new Sku("SKU-200118", "深沟球轴承 6204", "6204-2RS", "B-02-01-1", 320, 300, "B20240815", "套"),
        new Sku("SKU-300045", "铝型材 4040", "4040 长 2m", "C-05-02-1", 96, 96, "B20240720", "根"),
        new Sku("SKU-300046", "铝型材 4080", "4080 长 2m", "C-05-02-2", 54, 54, "B20240720", "根"),
        new Sku("SKU-400771", "工业交换机 8口", "8口千兆 导轨式", "D-01-01-1", 41, 38, "B20240611", "台"),
        new Sku("SKU-500902", "缠绕膜 PE", "宽 500mm 净重 3kg", "E-03-01-1", 210, 210, "B20240910", "卷"),
        new Sku("SKU-600314", "标签纸 热敏", "100x150mm 500张/卷", "E-03-02-1", 178, 178, "B20240902", "卷")
    };

    /** 关键词搜索（MOCK 实现） */
    public static Sku[] search(String keyword) {
        if (keyword == null || keyword.trim().length() == 0) return DEMO_SKUS;
        String k = keyword.trim().toLowerCase();
        java.util.List<Sku> out = new java.util.ArrayList<Sku>();
        for (int i = 0; i < DEMO_SKUS.length; i++) {
            Sku s = DEMO_SKUS[i];
            if (s.code.toLowerCase().contains(k) || s.name.toLowerCase().contains(k)
                    || s.location.toLowerCase().contains(k)) out.add(s);
        }
        return out.toArray(new Sku[out.size()]);
    }

    public static Sku findByCode(String code) {
        Sku[] all = DEMO_SKUS;
        for (int i = 0; i < all.length; i++) {
            if (all[i].code.equals(code)) return all[i];
        }
        return null;
    }

    /** 登录（MOCK：任意非空账号密码通过） */
    public static boolean mockLogin(String u, String p) {
        return u != null && u.trim().length() > 0 && p != null && p.length() > 0;
    }

    private ApiContract() {}
}
