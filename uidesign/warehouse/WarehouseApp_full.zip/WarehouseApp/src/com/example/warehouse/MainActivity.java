package com.example.warehouse;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/** 首页：仓储作业功能入口 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Activity self = this;

        android.widget.LinearLayout root = Ui.root(this);
        root.addView(Ui.muted(this, "当前账号：" + Session.username + "   终端：" + Session.terminal));
        root.addView(Ui.section(this, "作业"));

        Button b1 = Ui.button(this, "SKU 查询");
        b1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivity(new Intent(self, SkuListActivity.class)); }
        });
        Button b2 = Ui.button(this, "库位查询");
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivity(new Intent(self, LocationActivity.class)); }
        });
        root.addView(Ui.gridRow(this, b1, b2));

        Button b3 = Ui.button(this, "入库作业");
        b3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivity(new Intent(self, InboundActivity.class)); }
        });
        Button b4 = Ui.button(this, "出库作业");
        b4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivity(new Intent(self, OutboundActivity.class)); }
        });
        root.addView(Ui.gridRow(this, b3, b4));

        Button b5 = Ui.button(this, "库存盘点");
        b5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivity(new Intent(self, StocktakeActivity.class)); }
        });
        Button b6 = Ui.button(this, "我的");
        b6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivity(new Intent(self, ProfileActivity.class)); }
        });
        root.addView(Ui.gridRow(this, b5, b6));

        root.addView(Ui.divider(this));
        root.addView(Ui.muted(this, "接口契约共 " + ApiContract.ENDPOINTS.length + " 个，见「我的」页"));
        setContentView(root);
    }
}
