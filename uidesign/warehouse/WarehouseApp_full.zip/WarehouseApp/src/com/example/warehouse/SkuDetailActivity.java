package com.example.warehouse;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/** SKU 详情：展示库存属性，并提供入库 / 出库入口 */
public class SkuDetailActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Activity self = this;

        String code = getIntent().getStringExtra("code");
        ApiContract.Sku s = (code == null) ? ApiContract.DEMO_SKUS[0] : ApiContract.findByCode(code);
        if (s == null) s = ApiContract.DEMO_SKUS[0];

        android.widget.LinearLayout root = Ui.root(this);
        root.addView(Ui.info(this, "编码：" + s.code));
        root.addView(Ui.info(this, "品名：" + s.name));
        root.addView(Ui.info(this, "规格：" + s.spec));
        root.addView(Ui.divider(this));
        root.addView(Ui.info(this, "库位：" + s.location));
        root.addView(Ui.info(this, "库存：" + s.quantity + " " + s.unit));
        root.addView(Ui.info(this, "可用：" + s.available + " " + s.unit));
        root.addView(Ui.info(this, "批次：" + s.batchNo));

        final String finalCode = s.code;

        Button bi = Ui.button(this, "入  库");
        bi.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(self, InboundActivity.class);
                i.putExtra("code", finalCode);
                startActivity(i);
            }
        });
        Button bo = Ui.button(this, "出  库");
        bo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(self, OutboundActivity.class);
                i.putExtra("code", finalCode);
                startActivity(i);
            }
        });
        root.addView(Ui.gridRow(this, bi, bo));
        setContentView(root);
    }
}
