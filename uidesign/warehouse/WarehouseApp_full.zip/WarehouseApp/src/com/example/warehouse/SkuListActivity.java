package com.example.warehouse;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

/** SKU 查询列表 */
public class SkuListActivity extends Activity {

    private EditText etKey;
    private ListView list;
    private ApiContract.Sku[] shown = ApiContract.DEMO_SKUS;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Activity self = this;

        android.widget.LinearLayout root = Ui.root(this);
        etKey = Ui.field(this, "输入 SKU 编码 / 品名 / 库位", false);
        root.addView(etKey);

        Button btn = Ui.button(this, "搜  索");
        root.addView(btn);

        list = new ListView(this);
        list.setLayoutParams(Ui.lp());
        root.addView(list);

        refresh(ApiContract.DEMO_SKUS);

        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                refresh(ApiContract.search(etKey.getText().toString()));
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                Intent i = new Intent(self, SkuDetailActivity.class);
                i.putExtra("code", shown[pos].code);
                startActivity(i);
            }
        });

        setContentView(root);
    }

    private void refresh(ApiContract.Sku[] data) {
        shown = data;
        String[] lines = new String[data.length];
        for (int i = 0; i < data.length; i++) lines[i] = data[i].line();
        list.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, lines));
    }
}
