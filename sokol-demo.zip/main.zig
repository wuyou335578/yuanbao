const std = @import("std");
const sokol = @import("sokol");
const app = sokol.app;
const gfx = sokol.gfx;
const glue = sokol.glue;

var pass_action: gfx.PassAction = .{};

export fn init() void {
    gfx.setup(.{ .environment = glue.environment(), .logger = .{ .func = sokol.log.func } });
    pass_action.colors[0] = .{ .load_action = .CLEAR, .clear_value = .{ .r = 0.1, .g = 0.2, .b = 0.4, .a = 1 } };
    // ⚠️ 故意的 bug：size=0 的 buffer
    const bad = gfx.makeBuffer(.{ .size = 0, .usage = .{ .vertex_buffer = true } });
    std.debug.print("[init] buffer id={} (故意错误)\n", .{bad.id});
    std.debug.print("[init] sokol 初始化完成\n", .{});
}

export fn frame() void {
    gfx.beginPass(.{ .action = pass_action, .swapchain = glue.swapchain() });
    gfx.endPass();
    gfx.commit();
}

export fn cleanup() void {
    std.debug.print("[cleanup] 退出\n", .{});
    gfx.shutdown();
}

pub fn main() void {
    app.run(.{
        .init_cb = init,
        .frame_cb = frame,
        .cleanup_cb = cleanup,
        .width = 640,
        .height = 480,
        .window_title = "sokol test",
        .icon = .{ .sokol_default = true },
        .logger = .{ .func = sokol.log.func },
    });
}
